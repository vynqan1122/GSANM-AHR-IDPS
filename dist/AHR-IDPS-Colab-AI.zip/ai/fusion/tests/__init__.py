"""Fusion tests."""


"""Network AI tests."""

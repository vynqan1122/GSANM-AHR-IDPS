"""Network AI package."""

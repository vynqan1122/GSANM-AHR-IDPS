"""Log AI package."""

"""Log AI tests."""
